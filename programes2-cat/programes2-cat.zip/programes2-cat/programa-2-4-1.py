a=input("Entra un número ")
b=input("Entra un altre numero ")
c=float(a)/float(b)
print("La divisió és ",c)
