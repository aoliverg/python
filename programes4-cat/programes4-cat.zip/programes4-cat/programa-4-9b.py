from nltk.tokenize import word_tokenize

oracio="We need to conduct an assessment to learn whether a student's dificulties are because he or she can't or won't complete assignments."
tokens=word_tokenize(oracio)
print(tokens)
